
// let demo = document.getElementById('demo');

// demo.innerHTML = "Hello JavaScript";

// document.write('Helloooo buddy');

// window.alert('This page is ' + demo)

// console.log("hello java");

// window.print('hello python')


// let btnHide =  document.getElementById("btn-hide");

// let elements = document.getElementsByClassName("element");


// function for showing and hidding pera
let tagElemen = document.getElementById('demo');
let tagElement = tagElemen.querySelectorAll('p.element');

// console.log(tagElement[0].innerHTML); //selecting a particulor tags element


function show(){
    // tagElement[0].style.display = "block";
    tagElement[0].style.visibility = "visible";
}

function hide(){
    // tagElement[0].style.display = "none";
    tagElement[0].style.visibility = "hidden";
}


// function for hidding containt of a peragraph using id
let elements = document.getElementById("element");

function replace(){
    elements.innerHTML = "Button clicked !";
}

function revert(){
    elements.innerHTML = "Lorem ipsum dolor sit amet consectetur adipisicing elit. Placeat eaque nobis incidunt ipsa odio reiciendis ab! Eos vitae quia id!";
}


// function for changing attribute value of src using img id

let img = document.getElementById("image");

function on(){
    img.src = "./onn.png";
}

function off(){
    img.src = "./offf.png";
}

// function for showing full date of Wed Jul 31 2024 16:11:00 GMT+0530 (India Standard Time)

let date = document.getElementById("date");

function showDate(){
    date.innerHTML = Date();
}

function hideDate(){
    date.innerHTML = " ";
}


// validating a input only accept number between range 

function validate(){

    let result = document.getElementById('result');
    let number = document.getElementById('number').value;

    if(isNaN(number) || number < 1 || number > 10){
        result.innerHTML = "Input is Not Valid. ❌ "
        result.style.color = "red";
    }else{
        result.innerHTML = "Input is Okay. ✅ ";
        result.style.color = "green";

    }

}

// Animate 

// function animate(){

//     let id = null;
//     const element = document.getElementById("animate");
//     let pos = 0;
//     clearInterval(id);
//     id = setInterval(frame, 5);

//     function frame(){
//         if(pos >= 350){
//             clearInterval(id);
//         }else{
//             pos++;
//             element.style.right = pos + 'px';
//             element.style.top = pos + 'px';
//         }
//     }

// }


// animating a div

function animated() {
    let img = document.getElementById('img');
    img.src = "./Cat Walk Animated GIF.gif";
    let id = null;
    const element = document.getElementById("animate");
    const maxPos = window.innerWidth - element.offsetWidth;
    let pos = 0;
    clearInterval(id);
    id = setInterval(frame, 5);

    function frame() {
        if (pos >= maxPos - 90) {
            clearInterval(id);
            element.style.left = 0 + 'px';
            img.src = "./cat.png";

        } else {
            pos++;
            element.style.left = pos + 'px';
            // element.style.top = pos + 'px';
        }
    }
}


// Mouse over event

function mOver(demo){
    demo.innerHTML = "You'r mouse is here";
    demo.style.backgroundColor = "blue";
    demo.style.color = "#fff";
}

function mOut(demo){
    demo.innerHTML = "Hello Mouse is here (MouseOut is Working)";
    demo.style.backgroundColor = "transparent";
}


// addEventListener use

let Event = document.getElementById("addEvent");
let Event0 = document.getElementById("addEvent0");
let EventClick = document.getElementById("eventClick");


Event.addEventListener('click', addEvent);

function addEvent(){

    if (typeof(Storage) !== "undefined") {
        if (localStorage.clickcount) {
          localStorage.clickcount = Number(localStorage.clickcount)+1;
        } else {
          localStorage.clickcount = 0;
        }
    } else {
        alert("Sorry, your browser does not support web storage...");
    }

    Event.innerHTML = 'Clicked Count-> ' + localStorage.clickcount;
    
    
    if(count%2 == 0){
        EventClick.innerHTML = "You Click Even Time on Button";
        EventClick.style.backgroundColor = "green";
    }else{
        EventClick.innerHTML = "You Click Odd Time on Button";
        EventClick.style.backgroundColor = "red";
    }

    // localStorage.setItem(count);
    // alert("Button is clicked !");
}

Event0.addEventListener('click', function(){

    if (typeof(Storage) !== "undefined") {
        if (localStorage.clickcount) {
          localStorage.clickcount = 0;
        } else {
          localStorage.clickcount = 0;
        }
        alert("You are Click Count is set to 0");
    } else {
        alert("Sorry, Something Wrong Heppen");
    }

    addEvent();

});
